function indexFuction(){
alert("Something")
}