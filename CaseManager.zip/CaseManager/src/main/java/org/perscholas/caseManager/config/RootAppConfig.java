package org.perscholas.caseManager.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("org.perscholas.caseManager")
public class RootAppConfig {

}
