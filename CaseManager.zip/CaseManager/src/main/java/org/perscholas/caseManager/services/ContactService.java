package org.perscholas.caseManager.services;

import org.perscholas.caseManager.models.Contact;

public interface ContactService {
	
	
	public Contact save(Contact contact);
}
